//
// File: ros_line_follower_private.h
//
// Code generated for Simulink model 'ros_line_follower'.
//
// Model version                  : 4.23
// Simulink Coder version         : 9.5 (R2021a) 14-Nov-2020
// C/C++ source code generated on : Thu Apr  8 16:21:14 2021
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Linux 64)
// Code generation objective: Execution efficiency
// Validation result: Not run
//
#ifndef RTW_HEADER_ros_line_follower_private_h_
#define RTW_HEADER_ros_line_follower_private_h_
#include "rtwtypes.h"

extern real_T rt_atan2d_snf(real_T u0, real_T u1);

#endif                               // RTW_HEADER_ros_line_follower_private_h_

//
// File trailer for generated code.
//
// [EOF]
//
