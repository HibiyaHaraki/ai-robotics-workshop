//
// File: line_detection_types.h
//
// GPU Coder version                    : 2.1
// CUDA/C/C++ source code generated on  : 08-Apr-2021 15:32:32
//

#ifndef LINE_DETECTION_TYPES_H
#define LINE_DETECTION_TYPES_H

// Include Files
#include "rtwtypes.h"

#endif
//
// File trailer for line_detection_types.h
//
// [EOF]
//
