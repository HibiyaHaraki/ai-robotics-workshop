//
// File: line_detection_data.h
//
// GPU Coder version                    : 2.1
// CUDA/C/C++ source code generated on  : 08-Apr-2021 15:32:32
//

#ifndef LINE_DETECTION_DATA_H
#define LINE_DETECTION_DATA_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Variable Declarations
extern bool isInitialized_line_detection;

#endif
//
// File trailer for line_detection_data.h
//
// [EOF]
//
