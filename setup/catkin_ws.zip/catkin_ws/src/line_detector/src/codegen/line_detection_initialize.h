//
// File: line_detection_initialize.h
//
// GPU Coder version                    : 2.1
// CUDA/C/C++ source code generated on  : 08-Apr-2021 15:32:32
//

#ifndef LINE_DETECTION_INITIALIZE_H
#define LINE_DETECTION_INITIALIZE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void line_detection_initialize();

#endif
//
// File trailer for line_detection_initialize.h
//
// [EOF]
//
